void show_window_mand_msg ();
void show_window_login ();
void show_window_signup ();